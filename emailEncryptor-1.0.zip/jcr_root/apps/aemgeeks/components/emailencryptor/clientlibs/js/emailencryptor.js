/**
 * Email Encryptor Component
 *
 * Features:
 *  - Single email → base64 → generated URL displayed live
 *  - Excel upload (drag-and-drop or click) using SheetJS (loaded from CDN via
 *    a <script> tag we inject the first time the component initialises)
 *  - Preview table of email → URL pairs
 *  - Download result as an .xlsx file
 *
 * The Base URL is read from the data-base-url attribute set by the HTL template
 * (dialog field: ./baseUrl).  Falls back to the Abbott default.
 */
(function () {
    "use strict";

    /* ------------------------------------------------------------------ */
    /*  SheetJS CDN loader (only injected once per page)                   */
    /* ------------------------------------------------------------------ */
    var SHEETJS_CDN = "https://cdn.sheetjs.com/xlsx-0.20.2/package/dist/xlsx.full.min.js";
    var sheetJsReady = false;
    var sheetJsQueue = [];

    function withXLSX(cb) {
        if (typeof XLSX !== "undefined") {
            cb();
            return;
        }
        sheetJsQueue.push(cb);
        if (sheetJsReady) return; // script already being loaded
        sheetJsReady = true;
        var s = document.createElement("script");
        s.src = SHEETJS_CDN;
        s.onload = function () {
            sheetJsQueue.forEach(function (fn) { fn(); });
            sheetJsQueue = [];
        };
        document.head.appendChild(s);
    }

    /* ------------------------------------------------------------------ */
    /*  Utilities                                                           */
    /* ------------------------------------------------------------------ */

    /**
     * Encode a plain string to Base64 (btoa, UTF-8 safe).
     */
    function toBase64(str) {
        return btoa(
            encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function (_, p1) {
                return String.fromCharCode(parseInt(p1, 16));
            })
        );
    }

    /**
     * Build the full URL for a given email using the component's base URL.
     */
    function buildUrl(baseUrl, email) {
        return baseUrl + toBase64(email.trim());
    }

    /* ------------------------------------------------------------------ */
    /*  Component initialisation                                            */
    /* ------------------------------------------------------------------ */

    function EmailEncryptor(root) {
        this.root    = root;
        this.baseUrl = (root.getAttribute("data-base-url") || "https://www.hospitalTrainigAbbott.com?email=").trim();

        /* single-email elements */
        this.emailInput   = root.querySelector("#cmp-emailencryptor-input");
        this.resultBlock  = root.querySelector(".cmp-emailencryptor__result");
        this.resultLink   = root.querySelector(".cmp-emailencryptor__link");

        /* bulk-excel elements */
        this.dropzone     = root.querySelector("#cmp-emailencryptor-dropzone");
        this.fileInput    = root.querySelector("#cmp-emailencryptor-file");
        this.preview      = root.querySelector("#cmp-emailencryptor-preview");
        this.tbody        = root.querySelector("#cmp-emailencryptor-tbody");
        this.downloadBtn  = root.querySelector("#cmp-emailencryptor-download");

        /** Holds the processed rows [{email, url}] for the download step */
        this.rows = [];

        this._bindSingleEmail();
        this._bindExcel();
    }

    /* ------------------------------------------------------------------ */
    /*  Single-email binding                                                */
    /* ------------------------------------------------------------------ */

    EmailEncryptor.prototype._bindSingleEmail = function () {
        var self = this;
        this.emailInput.addEventListener("input", function () {
            var val = self.emailInput.value.trim();
            if (!val) {
                self.resultBlock.style.display = "none";
                return;
            }
            var url = buildUrl(self.baseUrl, val);
            self.resultLink.href        = url;
            self.resultLink.textContent = url;
            self.resultBlock.style.display = "block";
        });
    };

    /* ------------------------------------------------------------------ */
    /*  Excel drag-and-drop + file input                                   */
    /* ------------------------------------------------------------------ */

    EmailEncryptor.prototype._bindExcel = function () {
        var self = this;

        /* ---- drag events on the dropzone ---- */
        this.dropzone.addEventListener("dragover", function (e) {
            e.preventDefault();
            self.dropzone.classList.add("cmp-emailencryptor__dropzone--active");
        });

        this.dropzone.addEventListener("dragleave", function () {
            self.dropzone.classList.remove("cmp-emailencryptor__dropzone--active");
        });

        this.dropzone.addEventListener("drop", function (e) {
            e.preventDefault();
            self.dropzone.classList.remove("cmp-emailencryptor__dropzone--active");
            var file = e.dataTransfer.files && e.dataTransfer.files[0];
            if (file) self._processExcel(file);
        });

        /* ---- click opens the hidden file input ---- */
        this.dropzone.addEventListener("click", function () {
            self.fileInput.click();
        });

        this.fileInput.addEventListener("change", function () {
            var file = self.fileInput.files && self.fileInput.files[0];
            if (file) self._processExcel(file);
        });

        /* ---- download button ---- */
        this.downloadBtn.addEventListener("click", function () {
            self._downloadResult();
        });
    };

    /* ------------------------------------------------------------------ */
    /*  Parse the uploaded Excel file                                       */
    /* ------------------------------------------------------------------ */

    EmailEncryptor.prototype._processExcel = function (file) {
        var self = this;
        withXLSX(function () {
            var reader = new FileReader();
            reader.onload = function (e) {
                try {
                    var data     = new Uint8Array(e.target.result);
                    var workbook = XLSX.read(data, { type: "array" });
                    var sheet    = workbook.Sheets[workbook.SheetNames[0]];
                    var json     = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });

                    self.rows = [];
                    /* column A (index 0) = emails; skip header if it looks like one */
                    var startRow = 0;
                    if (json.length > 0) {
                        var firstCell = String(json[0][0]).toLowerCase();
                        if (firstCell === "email" || firstCell === "email id" || firstCell === "emailid") {
                            startRow = 1;
                        }
                    }

                    for (var i = startRow; i < json.length; i++) {
                        var email = String(json[i][0]).trim();
                        if (!email) continue;
                        self.rows.push({ email: email, url: buildUrl(self.baseUrl, email) });
                    }

                    self._renderPreview();
                } catch (err) {
                    alert("Failed to parse Excel file. Please ensure it is a valid .xlsx or .xls file.\n" + err.message);
                }
            };
            reader.readAsArrayBuffer(file);
        });
    };

    /* ------------------------------------------------------------------ */
    /*  Render preview table                                                */
    /* ------------------------------------------------------------------ */

    EmailEncryptor.prototype._renderPreview = function () {
        this.tbody.innerHTML = "";
        if (this.rows.length === 0) {
            this.preview.style.display = "none";
            return;
        }
        var frag = document.createDocumentFragment();
        this.rows.forEach(function (row) {
            var tr  = document.createElement("tr");
            var td1 = document.createElement("td");
            var td2 = document.createElement("td");
            td1.textContent = row.email;
            var a = document.createElement("a");
            a.href        = row.url;
            a.textContent = row.url;
            a.target      = "_blank";
            a.rel         = "noopener noreferrer";
            td2.appendChild(a);
            tr.appendChild(td1);
            tr.appendChild(td2);
            frag.appendChild(tr);
        });
        this.tbody.appendChild(frag);
        this.preview.style.display = "block";
    };

    /* ------------------------------------------------------------------ */
    /*  Download result as Excel                                            */
    /* ------------------------------------------------------------------ */

    EmailEncryptor.prototype._downloadResult = function () {
        var self = this;
        withXLSX(function () {
            var wsData = [["Email", "Generated URL"]];
            self.rows.forEach(function (row) {
                wsData.push([row.email, row.url]);
            });
            var ws = XLSX.utils.aoa_to_sheet(wsData);

            /* Auto-width for columns */
            var colWidths = wsData.reduce(function (acc, row) {
                row.forEach(function (cell, i) {
                    var len = cell ? String(cell).length : 10;
                    acc[i] = Math.max(acc[i] || 10, len);
                });
                return acc;
            }, []);
            ws["!cols"] = colWidths.map(function (w) { return { wch: w + 2 }; });

            var wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Results");
            XLSX.writeFile(wb, "email-urls-result.xlsx");
        });
    };

    /* ------------------------------------------------------------------ */
    /*  Boot: initialise every component on the page                       */
    /* ------------------------------------------------------------------ */

    function init() {
        var components = document.querySelectorAll("[data-cmp-is='emailencryptor']");
        components.forEach(function (el) {
            if (!el.__emailEncryptorInit) {
                el.__emailEncryptorInit = true;
                new EmailEncryptor(el);
            }
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }

    /* AEM author mode: re-init after component is added to the page */
    if (window.Granite && window.Granite.author) {
        document.addEventListener("cq-layer-activated", init);
        document.addEventListener("cq-async-content-loaded", init);
    }
}());
